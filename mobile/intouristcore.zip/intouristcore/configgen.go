package intouristcore

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/xjasonlyu/tun2socks/v2/core"
	"github.com/xjasonlyu/tun2socks/v2/core/device"
	"github.com/xjasonlyu/tun2socks/v2/log"
	"github.com/xjasonlyu/tun2socks/v2/option"
	"github.com/xjasonlyu/tun2socks/v2/transport/socks5"
)

// HelperModeSession manages the Android helpermode lifecycle
type HelperModeSession struct {
	tunDevice     device.Device
	tunFd         int
	socks5Addr    string
	multiplexer   *WSMultiplexer
	dialer        *ProtectedDialer
	ctx           context.Context
	cancel        context.CancelFunc
	wg            sync.WaitGroup
	logger        Logger
}

// NewHelperModeSession initializes helpermode with Android-specific protections
func NewHelperModeSession(tunFd int, dialer *ProtectedDialer, logger Logger) *HelperModeSession {
	ctx, cancel := context.WithCancel(context.Background())
	return &HelperModeSession{
		tunFd:      tunFd,
		socks5Addr: "127.0.0.1:1080",
		dialer:     dialer,
		ctx:        ctx,
		cancel:     cancel,
		logger:     logger,
	}
}

// Start initiates the helpermode connection lifecycle
func (h *HelperModeSession) Start(bridgeEndpoint, wsURL string) error {
	h.logger.Infof("Helpermode: Starting helpermode connection to %s", bridgeEndpoint)

	// Step 1: Resolve bridge endpoint IPs
	ips, err := h.resolveBridgeEndpoint(bridgeEndpoint)
	if err != nil {
		return fmt.Errorf("bridge endpoint resolution failed: %w", err)
	}
	h.logger.Infof("Helpermode: Resolved bridge endpoint IPs: %v", ips)

	// Step 2: Establish protected WebSocket multiplexer session
	multiplexer, err := h.establishWSMultiplexer(wsURL, ips)
	if err != nil {
		return fmt.Errorf("WSS multiplexer establishment failed: %w", err)
	}
	h.multiplexer = multiplexer
	defer func() {
		if err != nil {
			h.multiplexer.Close()
		}
	}()

	// Step 3: Start SOCKS5 listener (bound to protected socket)
	listener, err := h.startSOCKS5Listener()
	if err != nil {
		return fmt.Errorf("SOCKS5 listener start failed: %w", err)
	}
	h.wg.Add(1)
	go func() {
		defer h.wg.Done()
		h.acceptSOCKS5Connections(listener)
	}()

	// Step 4: Initialize tun2socks with TUN device
	if err := h.initializeTun2Socks(); err != nil {
		listener.Close()
		return fmt.Errorf("tun2socks initialization failed: %w", err)
	}

	// Step 5: Start tun2socks engine (will persist TUN fd and route traffic)
	h.wg.Add(1)
	go func() {
		defer h.wg.Done()
		if err := core.Run(h.ctx); err != nil {
			h.logger.Errorf("tun2socks engine error: %v", err)
		}
	}()

	// Step 6: Start multiplexer frame handler loop
	h.wg.Add(1)
	go func() {
		defer h.wg.Done()
		h.handleMultiplexerFrames()
	}()

	// Step 7: Monitor connection health and handle reconnections
	h.wg.Add(1)
	go func() {
		defer h.wg.Done()
		h.monitorConnectionHealth()
	}()

	h.logger.Infof("Helpermode: Connection established and running")
	return nil
}

// resolveBridgeEndpoint resolves bridge hostname to IPs using protected dialer
func (h *HelperModeSession) resolveBridgeEndpoint(endpoint string) ([]net.IP, error) {
	resolver := &net.Resolver{
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			// Use protected dialer to ensure DNS bypass
			return h.dialer.Dial(ctx, network, address)
		},
	}

	ips, err := resolver.LookupIP(h.ctx, "ip4", endpoint)
	if err != nil {
		return nil, err
	}

	if len(ips) == 0 {
		return nil, fmt.Errorf("bridge endpoint resolution returned no IPs")
	}

	return ips, nil
}

// establishWSMultiplexer creates and connects the WSS multiplexer
func (h *HelperModeSession) establishWSMultiplexer(wsURL string, bridgeIPs []net.IP) (*WSMultiplexer, error) {
	mux := NewWSMultiplexer(wsURL, h.dialer, h.logger)

	// Attempt connection to each bridge IP
	var lastErr error
	for _, ip := range bridgeIPs {
		wsURLWithIP := fmt.Sprintf("wss://%s/ws", ip.String())
		err := mux.Connect(h.ctx, wsURLWithIP)
		if err == nil {
			return mux, nil
		}
		lastErr = err
		h.logger.Warnf("Helpermode: Failed to connect to bridge IP %s: %v", ip.String(), err)
	}

	return nil, fmt.Errorf("failed to connect to any bridge IP: %w", lastErr)
}

// startSOCKS5Listener starts a protected SOCKS5 listener on 127.0.0.1:1080
func (h *HelperModeSession) startSOCKS5Listener() (net.Listener, error) {
	// Create a protected listener that won't route through the VPN
	listener, err := h.dialer.ProtectListener("tcp", h.socks5Addr)
	if err != nil {
		return nil, err
	}

	h.logger.Infof("Helpermode: SOCKS5 listener started on %s", h.socks5Addr)
	return listener, nil
}

// acceptSOCKS5Connections handles incoming SOCKS5 connections
func (h *HelperModeSession) acceptSOCKS5Connections(listener net.Listener) {
	for {
		select {
		case <-h.ctx.Done():
			listener.Close()
			return
		default:
		}

		conn, err := listener.Accept()
		if err != nil {
			h.logger.Debugf("Helpermode: SOCKS5 accept error: %v", err)
			return
		}

		// Handle SOCKS5 connection via multiplexer
		h.wg.Add(1)
		go func(c net.Conn) {
			defer h.wg.Done()
			h.handleSOCKS5Connection(c)
		}(conn)
	}
}

// handleSOCKS5Connection forwards SOCKS5 traffic through multiplexer
func (h *HelperModeSession) handleSOCKS5Connection(conn net.Conn) {
	defer conn.Close()

	// Parse SOCKS5 request and forward through multiplexer tunnel
	// This bridges local SOCKS5 client requests to remote helper service
	h.multiplexer.ProxyConnection(h.ctx, conn)
}

// initializeTun2Socks configures the TUN device and SOCKS5 transport
func (h *HelperModeSession) initializeTun2Socks() error {
	// Configure tun2socks with TUN device FD
	opts := []option.Option{
		option.WithDeviceAddress("10.0.0.1/24"), // Android VPN address (configurable)
		option.WithSOCKS5Listener(h.socks5Addr),
		option.WithTun(h.tunFd),
	}

	// Apply options to tun2socks core
	for _, opt := range opts {
		if err := opt.Apply(); err != nil {
			return err
		}
	}

	h.logger.Infof("Helpermode: tun2socks initialized with TUN fd %d", h.tunFd)
	return nil
}

// handleMultiplexerFrames processes incoming multiplexer frames
func (h *HelperModeSession) handleMultiplexerFrames() {
	for {
		select {
		case <-h.ctx.Done():
			return
		default:
		}

		frame, err := h.multiplexer.ReceiveFrame(h.ctx)
		if err != nil {
			h.logger.Errorf("Helpermode: Multiplexer frame error: %v", err)
			h.cancel()
			return
		}

		if frame == nil {
			continue
		}

		// Process frame switch based on type
		h.processMultiplexerFrame(frame)
	}
}

// processMultiplexerFrame handles multiplexer frame types
func (h *HelperModeSession) processMultiplexerFrame(frame *MultiplexerFrame) {
	switch frame.Type {
	case FrameTypeData:
		// Route data through SOCKS5 tunnel
	case FrameTypeKeepAlive:
		// Refresh connection heartbeat
		h.multiplexer.SendKeepAlive(h.ctx)
	case FrameTypeClose:
		h.logger.Infof("Helpermode: Multiplexer close frame received")
		h.cancel()
	}
}

// monitorConnectionHealth monitors and maintains connection
func (h *HelperModeSession) monitorConnectionHealth() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-h.ctx.Done():
			return
		case <-ticker.C:
			// Check multiplexer and tun2socks health
			if !h.multiplexer.IsAlive() {
				h.logger.Warnf("Helpermode: Multiplexer lost connection")
				h.cancel()
				return
			}

			// Ensure TUN fd is still valid
			if !h.isTunDeviceValid() {
				h.logger.Errorf("Helpermode: TUN device fd is invalid")
				h.cancel()
				return
			}
		}
	}
}

// isTunDeviceValid checks if the TUN file descriptor is still valid
func (h *HelperModeSession) isTunDeviceValid() bool {
	// Check FD validity by attempting a no-op syscall
	// This is implementation-specific based on Android/Linux FD management
	return true // Placeholder; implement actual FD validation
}

// Stop gracefully stops the helpermode session
func (h *HelperModeSession) Stop() error {
	h.logger.Infof("Helpermode: Stopping session")
	h.cancel()
	h.wg.Wait()

	if h.multiplexer != nil {
		h.multiplexer.Close()
	}

	h.logger.Infof("Helpermode: Session stopped")
	return nil
}