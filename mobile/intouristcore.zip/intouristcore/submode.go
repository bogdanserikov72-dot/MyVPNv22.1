package intouristcore

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"

	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/infra/conf"
)

// SubModeSession manages Xray-based submode for Android
type SubModeSession struct {
	config        *conf.Config
	xrayInstance  *core.Instance
	ctx           context.Context
	cancel        context.CancelFunc
	wg            sync.WaitGroup
	logger        Logger
	cacheDirPath  string // Android app cache directory
}

// NewSubModeSession initializes submode with in-memory configuration
func NewSubModeSession(cacheDirPath string, logger Logger) *SubModeSession {
	ctx, cancel := context.WithCancel(context.Background())
	return &SubModeSession{
		ctx:          ctx,
		cancel:       cancel,
		logger:       logger,
		cacheDirPath: cacheDirPath,
	}
}

// Start initiates Xray-based submode
func (s *SubModeSession) Start(config interface{}, servers []ServerConfig) error {
	s.logger.Infof("Submode: Starting Xray submode")

	// Step 1: Generate in-memory Xray configuration
	xrayConfig, err := s.generateInMemoryConfig(config, servers)
	if err != nil {
		return fmt.Errorf("config generation failed: %w", err)
	}
	s.config = xrayConfig

	// Step 2: Create Xray core instance from in-memory config
	xrayInstance, err := s.createXrayInstance(xrayConfig)
	if err != nil {
		return fmt.Errorf("xray instance creation failed: %w", err)
	}
	s.xrayInstance = xrayInstance

	// Step 3: Start Xray engine
	if err := s.xrayInstance.Start(); err != nil {
		return fmt.Errorf("xray start failed: %w", err)
	}

	s.logger.Infof("Submode: Xray instance started successfully")
	return nil
}

// generateInMemoryConfig generates Xray configuration in memory without writing files
func (s *SubModeSession) generateInMemoryConfig(config interface{}, servers []ServerConfig) (*conf.Config, error) {
	xrayConf := &conf.Config{}

	// Parse input config (if provided as JSON string or object)
	if configStr, ok := config.(string); ok {
		if err := json.Unmarshal([]byte(configStr), xrayConf); err != nil {
			return nil, fmt.Errorf("config parsing failed: %w", err)
		}
	} else if configMap, ok := config.(map[string]interface{}); ok {
		data, err := json.Marshal(configMap)
		if err != nil {
			return nil, fmt.Errorf("config marshaling failed: %w", err)
		}
		if err := json.Unmarshal(data, xrayConf); err != nil {
			return nil, fmt.Errorf("config unmarshaling failed: %w", err)
		}
	}

	// Step 1: Configure inbound (SOCKS5 local listener)
	xrayConf.Inbound = []*conf.InboundDetourConfig{
		{
			Protocol: "socks",
			PortRange: &net.PortRange{
				From: 1080,
				To:   1080,
			},
			Settings: &json.RawMessage{},
		},
	}

	// Step 2: Configure outbound via configured servers
	if len(servers) > 0 {
		outbounds := make([]*conf.OutboundDetourConfig, 0)
		for i, server := range servers {
			outbound := s.createOutboundFromServer(server)
			outbounds = append(outbounds, outbound)

			if i == 0 {
				// First server is default outbound
				xrayConf.Outbound = outbound
			}
		}
		xrayConf.OutboundDetours = outbounds
	}

	// Step 3: Configure DNS (use system DNS or custom)
	xrayConf.DNS = &conf.DNSConfig{
		Servers: []*conf.NameServerConfig{
			{
				Address: &net.IPOrDomain{
					Address: &net.IPOrDomain_Ip{
						Ip: []byte{8, 8, 8, 8}, // Google DNS fallback
					},
				},
			},
		},
	}

	// Step 4: Configure routing rules
	xrayConf.Router = &conf.RouterConfig{
		Rules: []*conf.RoutingRule{
			{
				Type:   "field",
				Domain: []string{"geosite:cn"},
				Outbound: &conf.OutboundDetourConfig{
					Tag: "direct",
				},
			},
		},
	}

	s.logger.Debugf("Submode: In-memory Xray config generated successfully")
	return xrayConf, nil
}

// createOutboundFromServer creates an outbound config from a server definition
func (s *SubModeSession) createOutboundFromServer(server ServerConfig) *conf.OutboundDetourConfig {
	outbound := &conf.OutboundDetourConfig{
		Protocol: server.Protocol, // "vmess", "trojan", "vless", etc.
		Tag:      fmt.Sprintf("server-%s", server.Name),
	}

	// Serialize server config to JSON settings
	settingsData, _ := json.Marshal(server.Settings)
	rawMsg := json.RawMessage(settingsData)
	outbound.Settings = &rawMsg

	return outbound
}

// createXrayInstance creates an Xray core instance from in-memory config
func (s *SubModeSession) createXrayInstance(xrayConf *conf.Config) (*core.Instance, error) {
	// Convert conf.Config to core.Config
	coreConfig, err := xrayConf.Build()
	if err != nil {
		return nil, fmt.Errorf("config build failed: %w", err)
	}

	// Create Xray instance from core config
	xrayInstance, err := core.New(coreConfig)
	if err != nil {
		return nil, fmt.Errorf("xray instance creation failed: %w", err)
	}

	s.logger.Infof("Submode: Xray instance created from in-memory config")
	return xrayInstance, nil
}

// Stop gracefully stops the submode session
func (s *SubModeSession) Stop() error {
	s.logger.Infof("Submode: Stopping Xray submode")
	s.cancel()

	if s.xrayInstance != nil {
		if err := s.xrayInstance.Close(); err != nil {
			s.logger.Errorf("Submode: Xray close error: %v", err)
			return err
		}
	}

	s.wg.Wait()
	s.logger.Infof("Submode: Xray submode stopped")
	return nil
}

// ServerConfig represents a proxy server configuration
type ServerConfig struct {
	Name      string                 `json:"name"`
	Protocol  string                 `json:"protocol"` // vmess, trojan, vless, etc.
	Address   string                 `json:"address"`
	Port      int                    `json:"port"`
	Settings  map[string]interface{} `json:"settings"`
}